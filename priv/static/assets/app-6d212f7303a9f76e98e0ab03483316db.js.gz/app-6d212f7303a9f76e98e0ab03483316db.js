(()=>{console.log("Hello");})();
